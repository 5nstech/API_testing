package mavendemo.apitesting;

public class Properties {

}
