package mavendemo.apitesting;

import org.hamcrest.core.IsEqual;
import org.json.simple.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import static io.restassured.RestAssured.given;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.ResponseSpecification;

public class ApiTesting {
	ResponseSpecification spec = null;
	@BeforeClass
	public void setSpecification() {
		spec = RestAssured.expect();
		spec.contentType(ContentType.JSON);
		spec.statusCode(200);
		spec.statusLine("HTTP/1.1 200 OK");
		ExtentReportManager.createReport();
	}
	@Test
	public void getListOfUsers() {
		ExtentReportManager.test = ExtentReportManager.reports.startTest("getListOfUsers","Get the list of Users");
		try {
			RestAssured.baseURI = "https://dummy.restapiexample.com/";
			ExtentReportManager.test.log(LogStatus.INFO, "Configured the base URL",RestAssured.baseURI);
			ExtentReportManager.test.log(LogStatus.INFO, "Get API call","api/v1/employees");
			ExtentReportManager.test.log(LogStatus.INFO, "Expected Message","Successfully! All records has been fetched.");
			given().when().get("api/v1/employees").then().assertThat().body("message", IsEqual.equalTo("Successfully! All records has been fetched."));
		}
		
		catch(Exception ex) {
			ExtentReportManager.test.log(LogStatus.ERROR, "Expection occured",ex.getMessage());
			ExtentReportManager.test.log(LogStatus.FAIL, "Failed",ex.getMessage());
		}
	}
	@Test
	public void createUsers() {
		ExtentReportManager.test = ExtentReportManager.reports.startTest("Create Users","Create Users");
		try {
			RestAssured.baseURI = "https://dummy.restapiexample.com/";
			ExtentReportManager.test.log(LogStatus.INFO, "Configured the base URL",RestAssured.baseURI);
			ExtentReportManager.test.log(LogStatus.INFO, "Get API call","api/v1/create");
			JSONObject params = new JSONObject();
			params.put("name", "Jacob");
			params.put("age", "20");
			params.put("salary", "200000");
	given().when().header("Content-Type", "application/json").body(params.toJSONString()).post("api/v1/create");
		}
		
		catch(Exception ex) {
			ExtentReportManager.test.log(LogStatus.ERROR, "Expection occured",ex.getMessage());
			ExtentReportManager.test.log(LogStatus.FAIL, "Failed",ex.getMessage());
		}
	}
	
	@Test
	public void updateUsers() {
		ExtentReportManager.test = ExtentReportManager.reports.startTest("Update user","Update user record");
		try {
			RestAssured.baseURI = "https://dummy.restapiexample.com/";
			ExtentReportManager.test.log(LogStatus.INFO, "Configured the base URL",RestAssured.baseURI);
			ExtentReportManager.test.log(LogStatus.INFO, "Get API call","/api/v1/update/<id>");
			ExtentReportManager.test.log(LogStatus.INFO, "Employee Id","21");
			ExtentReportManager.test.log(LogStatus.INFO, "Expected Message","Successfully! Record has been updated.");
			given().when().put("api/v1/update/21").then().assertThat().body("message", IsEqual.equalTo("Successfully! Record has been updated."));
		}
		
		catch(Exception ex) {
			ExtentReportManager.test.log(LogStatus.ERROR, "Expection occured",ex.getMessage());
			ExtentReportManager.test.log(LogStatus.FAIL, "Failed",ex.getMessage());
		}
	}
	
	
	
	@Test
	public void deleteUsers() {
		ExtentReportManager.test = ExtentReportManager.reports.startTest("Delete user","Delete user record");
		try {
			RestAssured.baseURI = "https://dummy.restapiexample.com/";
			ExtentReportManager.test.log(LogStatus.INFO, "Configured the base URL",RestAssured.baseURI);
			ExtentReportManager.test.log(LogStatus.INFO, "Get API call","/api/v1/delete/<id>");
			ExtentReportManager.test.log(LogStatus.INFO, "Employee Id","2");
			ExtentReportManager.test.log(LogStatus.INFO, "Expected Message","Successfully! Record has been deleted");
			given().when().delete("api/v1/delete/2").then().assertThat().body("message", IsEqual.equalTo("Successfully! Record has been deleted"));
		}
		
		catch(Exception ex) {
			ExtentReportManager.test.log(LogStatus.ERROR, "Expection occured",ex.getMessage());
			ExtentReportManager.test.log(LogStatus.FAIL, "Failed",ex.getMessage());
		}
	}
	
	public void endReport() {
		ExtentReportManager.reports.flush();
	}
	

}
